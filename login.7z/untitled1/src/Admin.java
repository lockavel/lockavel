import java.util.Date;

public class Admin {
    private String id;                 //编号
    private String name;           //姓名
    private String password;      //密码
    private Date date;
    void setID(String id) {
        this.id=id;
    }
    void setName(String name) {
        this.name=name;
    }
    void setPassword(String password) {
        this.password=password;
    }

    String getID() {
        return this.id;
    }
    String getName() {
        return this.name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    String getPassword() {
        return this.password;
    }

}


